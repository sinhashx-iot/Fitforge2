package com.fitforge.personal

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.fitforge.personal.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

class MainViewModel(private val context: Context) : ViewModel() {
    private val db = AppDatabase.get(context)
    val finance = db.financeDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val fitness = db.fitnessDao().observe(today())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FitnessDay(today()))

    fun updateFitness(transform: (FitnessDay) -> FitnessDay) = viewModelScope.launch {
        db.fitnessDao().save(transform(fitness.value))
    }
    fun addFinance(title: String, amount: Double, type: String, category: String) =
        viewModelScope.launch {
            db.financeDao().insert(FinanceEntry(
                date = today(), title = title, amount = amount,
                type = type, category = category
            ))
        }
    fun deleteFinance(e: FinanceEntry) = viewModelScope.launch { db.financeDao().delete(e) }
}

@Composable
fun FitForgeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF7C4DFF),
            secondary = Color(0xFF00D4FF),
            background = Color(0xFF090B12),
            surface = Color(0xFF121522)
        ),
        content = content
    )
}

class MainActivity : ComponentActivity() {
    private val activityPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED
        ) activityPermission.launch(Manifest.permission.ACTIVITY_RECOGNITION)

        setContent { FitForgeTheme { FitForgeApp(this) } }
    }
}

@Composable
fun FitForgeApp(context: Context, vm: MainViewModel = viewModel()) {
    var intro by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(2200)
        intro = false
    }
    AnimatedContent(targetState = intro, label = "intro") { show ->
        if (show) CinematicIntro() else MainShell(context, vm)
    }
}

@Composable
fun CinematicIntro() {
    val infinite = rememberInfiniteTransition(label = "hero")
    val scale by infinite.animateFloat(
        0.82f, 1.08f,
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse),
        label = "scale"
    )
    val alpha by infinite.animateFloat(
        0.25f, 0.85f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "alpha"
    )
    Box(
        Modifier.fillMaxSize().background(
            Brush.radialGradient(listOf(Color(0xFF24104D), Color(0xFF090B12)))
        ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(
                Brush.radialGradient(listOf(Color(0x447C4DFF), Color.Transparent)),
                radius = size.minDimension * .48f,
                center = center
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(132.dp).scale(scale).background(
                    Brush.linearGradient(listOf(Color(0xFF7C4DFF), Color(0xFF00D4FF))),
                    CircleShape
                ),
                contentAlignment = Alignment.Center
            ) {
                Text("F", style = MaterialTheme.typography.displayLarge,
                    fontWeight = FontWeight.Black, color = Color.White)
            }
            Spacer(Modifier.height(24.dp))
            Text("FITFORGE", style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Black, color = Color.White)
            Text("TRAIN • TRACK • CONQUER", modifier = Modifier.alpha(alpha),
                color = Color(0xFFBFC7FF), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MainShell(context: Context, vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = Color(0xFF090B12),
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0E111B)) {
                NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.FitnessCenter, null) }, label = { Text("Fitness") })
                NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.AccountBalanceWallet, null) }, label = { Text("Finance") })
                NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.BarChart, null) }, label = { Text("Stats") })
            }
        }
    ) { pad ->
        when (tab) {
            0 -> FitnessScreen(vm, Modifier.padding(pad))
            1 -> FinanceScreen(vm, Modifier.padding(pad))
            else -> StatsScreen(vm, Modifier.padding(pad))
        }
    }
}

@Composable
fun FitnessScreen(vm: MainViewModel, modifier: Modifier = Modifier) {
    val day by vm.fitness.collectAsState()
    val steps = day?.steps ?: 0
    val goal = 10000
    LazyColumn(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Good evening, Champion", style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black, color = Color.White)
            Text(today(), color = Color.Gray)
        }
        item { MetricCard("DAILY STEPS", "$steps / $goal", steps.toFloat()/goal, Icons.Default.DirectionsWalk) {
            StepEditor(vm, steps)
        }}
        item { MetricCard("WORKOUT", "${day?.workoutMinutes ?: 0} min", ((day?.workoutMinutes ?: 0)/60f).coerceAtMost(1f), Icons.Default.FitnessCenter) {
            NumberEditor("Workout minutes", day?.workoutMinutes ?: 0) { v ->
                vm.updateFitness { it.copy(workoutMinutes = v) }
            }
        }}
        item { MetricCard("WATER", "${day?.waterMl ?: 0} ml / 2500 ml", ((day?.waterMl ?: 0)/2500f).coerceAtMost(1f), Icons.Default.WaterDrop) {
            NumberEditor("Water (ml)", day?.waterMl ?: 0) { v ->
                vm.updateFitness { it.copy(waterMl = v) }
            }
        }}
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF121522))) {
                Column(Modifier.padding(18.dp)) {
                    Text("Quick actions", fontWeight = FontWeight.Bold, color = Color.White)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button({ vm.updateFitness { it.copy(steps = it.steps + 500) } }) { Text("+500 steps") }
                        OutlinedButton({ vm.updateFitness { it.copy(waterMl = it.waterMl + 250) } }) { Text("+250ml") }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, progress: Float, icon: androidx.compose.ui.graphics.vector.ImageVector, editor: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF121522)),
        shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.width(10.dp))
                Text(title, color = Color.Gray, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text(value, color = Color.White, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator({ progress.coerceIn(0f,1f) }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            editor()
        }
    }
}

@Composable
fun StepEditor(vm: MainViewModel, current: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton({ vm.updateFitness { it.copy(steps = (it.steps - 500).coerceAtLeast(0)) } }) { Text("-500") }
        Spacer(Modifier.width(10.dp))
        OutlinedButton({ vm.updateFitness { it.copy(steps = it.steps + 500) } }) { Text("+500") }
    }
}

@Composable
fun NumberEditor(label: String, current: Int, save: (Int) -> Unit) {
    var text by remember(current) { mutableStateOf(current.toString()) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(text, { text = it }, label = { Text(label) },
            modifier = Modifier.weight(1f), singleLine = true)
        Spacer(Modifier.width(8.dp))
        Button({ text.toIntOrNull()?.let(save) }) { Text("Save") }
    }
}

@Composable
fun FinanceScreen(vm: MainViewModel, modifier: Modifier = Modifier) {
    val entries by vm.finance.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    val income = entries.filter { it.type == "income" }.sumOf { it.amount }
    val expense = entries.filter { it.type == "expense" }.sumOf { it.amount }
    val balance = income - expense

    if (showAdd) FinanceDialog(vm) { showAdd = false }

    Column(modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Daily Finance", style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black, color = Color.White)
                Text("Everything stays on this phone.", color = Color.Gray)
            }
            FloatingActionButton({ showAdd = true }) { Icon(Icons.Default.Add, null) }
        }
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF121522))) {
            Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                FinanceStat("Balance", balance)
                FinanceStat("Income", income)
                FinanceStat("Spent", expense)
            }
        }
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(entries) { e ->
                ListItem(
                    headlineContent = { Text(e.title, color = Color.White) },
                    supportingContent = { Text("${e.category} • ${e.date}") },
                    trailingContent = {
                        Text("${if (e.type=="income") "+" else "-"}₹${"%.2f".format(e.amount)}",
                            color = if(e.type=="income") Color(0xFF66FF99) else Color(0xFFFF6B6B),
                            fontWeight = FontWeight.Bold)
                    },
                    colors = ListItemDefaults.colors(containerColor = Color(0xFF121522))
                )
            }
        }
    }
}

@Composable
fun FinanceStat(label: String, value: Double) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Color.Gray)
        Text("₹${"%.0f".format(value)}", color = Color.White, fontWeight = FontWeight.Black)
    }
}

@Composable
fun FinanceDialog(vm: MainViewModel, close: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Food") }
    var type by remember { mutableStateOf("expense") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("Add transaction") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Title") })
                OutlinedTextField(amount, { amount = it }, label = { Text("Amount ₹") })
                OutlinedTextField(category, { category = it }, label = { Text("Category") })
                Row {
                    FilterChip(type=="expense", { type="expense" }, label={Text("Expense")})
                    Spacer(Modifier.width(8.dp))
                    FilterChip(type=="income", { type="income" }, label={Text("Income")})
                }
            }
        },
        confirmButton = {
            Button({
                amount.toDoubleOrNull()?.let {
                    vm.addFinance(title.ifBlank { "Untitled" }, it, type, category.ifBlank {"Other"})
                    close()
                }
            }) { Text("Add") }
        },
        dismissButton = { TextButton(close) { Text("Cancel") } }
    )
}

@Composable
fun StatsScreen(vm: MainViewModel, modifier: Modifier = Modifier) {
    val day by vm.fitness.collectAsState()
    val entries by vm.finance.collectAsState()
    val spent = entries.filter { it.type=="expense" }.sumOf { it.amount }
    LazyColumn(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Your Stats", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = Color.White) }
        item { SummaryCard("Steps", "${day?.steps ?: 0}") }
        item { SummaryCard("Workout", "${day?.workoutMinutes ?: 0} minutes") }
        item { SummaryCard("Water", "${day?.waterMl ?: 0} ml") }
        item { SummaryCard("Total expenses", "₹${"%.2f".format(spent)}") }
        item {
            Text("Privacy", fontWeight = FontWeight.Bold, color = Color.White)
            Text("No account, no cloud database, no signup. Fitness and finance data are stored locally in FitForge's Room database.",
                color = Color.Gray)
        }
    }
}

@Composable
fun SummaryCard(label: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF121522))) {
        Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color.Gray)
            Text(value, color = Color.White, fontWeight = FontWeight.Black)
        }
    }
}
