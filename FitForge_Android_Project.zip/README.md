# FitForge — Personal Fitness + Finance Android App

A local-first Android app with:
- No signup/login
- No server/backend
- Fitness dashboard
- Daily steps, workout minutes and water tracking
- Personal finance income/expense tracking
- Daily balance and stats
- Original cinematic superhero-style opening animation
- Room local database

## Build APK

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect your Android phone with USB debugging enabled.
4. Run the `app` configuration, or use:
   `Build > Build APK(s)`
5. For a release APK:
   `Build > Generate Signed App Bundle / APK > APK`

The app uses Android API 26+ and targets API 35.

## Important

The opening animation is original "cinematic superhero" styling, not Marvel copyrighted artwork, logos, music, or characters.

The current version intentionally keeps data local. If the app is uninstalled, Android may remove its local database.
